/* ===========================================================
   توابع مشترک: API، احراز هویت، انیمیشن اسکرول، پیام‌ها
=========================================================== */
const API_BASE = "http://localhost:8000";

// ---------- ذخیره‌سازی نشست ----------
const Auth = {
  getToken() {
    return localStorage.getItem("pf_token");
  },
  getUser() {
    const raw = localStorage.getItem("pf_user");
    return raw ? JSON.parse(raw) : null;
  },
  setSession(token, user) {
    localStorage.setItem("pf_token", token);
    localStorage.setItem("pf_user", JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem("pf_token");
    localStorage.removeItem("pf_user");
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  isAdmin() {
    const u = this.getUser();
    return !!(u && u.is_admin);
  },
  requireLogin() {
    if (!this.isLoggedIn()) {
      window.location.href = "login.html";
    }
  },
  requireAdmin() {
    if (!this.isLoggedIn() || !this.isAdmin()) {
      window.location.href = "index.html";
    }
  },
};

// ---------- فراخوانی API ----------
async function apiFetch(path, options = {}) {
  const headers = options.headers || {};
  if (Auth.getToken()) {
    headers["Authorization"] = `Bearer ${Auth.getToken()}`;
  }
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (res.status === 401) {
    Auth.clear();
    window.location.href = "login.html";
    return null;
  }

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    /* بدون بدنه */
  }

  if (!res.ok) {
    const message = (data && data.detail) || "خطایی رخ داد";
    throw new Error(message);
  }
  return data;
}

// ---------- پیام (toast) ----------
function showToast(message, type = "default") {
  let toast = document.getElementById("toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.remove("show"), 3200);
}

// ---------- انیمیشن اسکرول (نمایش/محو تکرارپذیر) ----------
function initScrollReveal() {
  const items = document.querySelectorAll(".reveal");
  if (!items.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        entry.target.classList.toggle("in-view", entry.isIntersecting);
      });
    },
    { threshold: 0.12, rootMargin: "-40px 0px -40px 0px" }
  );

  items.forEach((el) => observer.observe(el));
}

// ---------- هدر: وضعیت ورود ----------
function renderAuthNav() {
  const slot = document.getElementById("nav-auth-slot");
  if (!slot) return;

  const user = Auth.getUser();
  if (!user) {
    slot.innerHTML = `<a href="login.html" class="btn btn-primary btn-sm">ورود</a>`;
    return;
  }

  const adminLink = user.is_admin
    ? `<a href="admin.html" class="nav-link">پنل ادمین</a>`
    : "";

  slot.innerHTML = `
    ${adminLink}
    <span class="nav-link mono" style="color:var(--text-faint)">${user.full_name}</span>
    <button id="logout-btn" class="btn btn-ghost btn-sm">خروج</button>
  `;

  document.getElementById("logout-btn").addEventListener("click", () => {
    Auth.clear();
    window.location.href = "login.html";
  });
}

document.addEventListener("DOMContentLoaded", () => {
  initScrollReveal();
  renderAuthNav();
});
