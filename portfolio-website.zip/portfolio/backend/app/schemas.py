"""
اسکیمای پایدانتیک برای اعتبارسنجی ورودی/خروجی API
"""
from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


# ---------- کاربر ----------
class UserRegister(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=120)
    phone: str = Field(..., min_length=10, max_length=20)
    password: str = Field(..., min_length=4, max_length=100)


class UserLogin(BaseModel):
    phone: str
    password: str


class UserOut(BaseModel):
    id: int
    full_name: str
    phone: str
    is_admin: bool
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- نمونه‌کار ----------
class ProjectBase(BaseModel):
    title: str = Field(..., min_length=1, max_length=150)
    short_description: str = Field(..., min_length=1, max_length=300)
    full_description: Optional[str] = None
    site_url: Optional[str] = None
    tags: Optional[str] = None
    display_order: Optional[int] = 0


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    short_description: Optional[str] = None
    full_description: Optional[str] = None
    site_url: Optional[str] = None
    tags: Optional[str] = None
    display_order: Optional[int] = None


class ProjectOut(ProjectBase):
    id: int
    image_path: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True
