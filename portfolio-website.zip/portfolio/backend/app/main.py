"""
اپلیکیشن اصلی FastAPI برای سایت پورتفولیو
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from . import models
from .database import engine
from .routers import auth_router, projects_router

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Portfolio API", description="بک‌اند سایت نمونه‌کارهای برنامه‌نویسی")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.include_router(auth_router.router)
app.include_router(projects_router.router)


@app.get("/api/health")
def health_check():
    return {"status": "ok"}
