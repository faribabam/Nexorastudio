"""
مسیرهای مربوط به ثبت‌نام و ورود کاربران
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/api/auth", tags=["احراز هویت"])

ADMIN_PHONE = "09113526007"


def normalize_phone(phone: str) -> str:
    return phone.strip().replace(" ", "").replace("-", "")


@router.post("/register", response_model=schemas.Token)
def register(payload: schemas.UserRegister, db: Session = Depends(get_db)):
    phone = normalize_phone(payload.phone)

    existing = db.query(models.User).filter(models.User.phone == phone).first()
    if existing:
        raise HTTPException(status_code=400, detail="این شماره موبایل قبلاً ثبت‌نام کرده است")

    is_admin = phone == ADMIN_PHONE

    user = models.User(
        full_name=payload.full_name.strip(),
        phone=phone,
        hashed_password=auth.hash_password(payload.password),
        is_admin=is_admin,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = auth.create_access_token({"sub": str(user.id)})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.post("/login", response_model=schemas.Token)
def login(payload: schemas.UserLogin, db: Session = Depends(get_db)):
    phone = normalize_phone(payload.phone)
    user = db.query(models.User).filter(models.User.phone == phone).first()

    if not user or not auth.verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="شماره موبایل یا رمز عبور اشتباه است")

    token = auth.create_access_token({"sub": str(user.id)})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.get("/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(auth.get_current_user)):
    return current_user
