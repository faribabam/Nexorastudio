"""
مسیرهای مربوط به نمونه‌کارها: نمایش عمومی + مدیریت توسط ادمین
"""
import os
import uuid
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from .. import models, schemas, auth
from ..database import get_db

router = APIRouter(prefix="/api/projects", tags=["نمونه‌کارها"])

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


# ---------- عمومی ----------
@router.get("", response_model=List[schemas.ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return (
        db.query(models.Project)
        .order_by(models.Project.display_order.asc(), models.Project.id.desc())
        .all()
    )


@router.get("/{project_id}", response_model=schemas.ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="نمونه‌کار یافت نشد")
    return project


# ---------- مدیریت (فقط ادمین) ----------
@router.post("", response_model=schemas.ProjectOut)
def create_project(
    title: str = Form(...),
    short_description: str = Form(...),
    full_description: Optional[str] = Form(None),
    site_url: Optional[str] = Form(None),
    tags: Optional[str] = Form(None),
    display_order: int = Form(0),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    _admin: models.User = Depends(auth.get_current_admin),
):
    image_path = _save_image(image) if image and image.filename else None

    project = models.Project(
        title=title,
        short_description=short_description,
        full_description=full_description,
        site_url=site_url,
        tags=tags,
        display_order=display_order,
        image_path=image_path,
    )
    db.add(project)
    db.commit()
    db.refresh(project)
    return project


@router.put("/{project_id}", response_model=schemas.ProjectOut)
def update_project(
    project_id: int,
    title: Optional[str] = Form(None),
    short_description: Optional[str] = Form(None),
    full_description: Optional[str] = Form(None),
    site_url: Optional[str] = Form(None),
    tags: Optional[str] = Form(None),
    display_order: Optional[int] = Form(None),
    image: Optional[UploadFile] = File(None),
    db: Session = Depends(get_db),
    _admin: models.User = Depends(auth.get_current_admin),
):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="نمونه‌کار یافت نشد")

    if title is not None:
        project.title = title
    if short_description is not None:
        project.short_description = short_description
    if full_description is not None:
        project.full_description = full_description
    if site_url is not None:
        project.site_url = site_url
    if tags is not None:
        project.tags = tags
    if display_order is not None:
        project.display_order = display_order
    if image and image.filename:
        project.image_path = _save_image(image)

    db.commit()
    db.refresh(project)
    return project


@router.delete("/{project_id}")
def delete_project(
    project_id: int,
    db: Session = Depends(get_db),
    _admin: models.User = Depends(auth.get_current_admin),
):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="نمونه‌کار یافت نشد")

    if project.image_path:
        full_path = os.path.join(UPLOAD_DIR, os.path.basename(project.image_path))
        if os.path.exists(full_path):
            os.remove(full_path)

    db.delete(project)
    db.commit()
    return {"message": "نمونه‌کار حذف شد"}


def _save_image(image: UploadFile) -> str:
    ext = os.path.splitext(image.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="فرمت تصویر مجاز نیست")

    filename = f"{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(image.file.read())

    return f"/static/uploads/{filename}"
